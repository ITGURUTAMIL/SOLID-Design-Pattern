﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIP_Demo
{
    public interface ILogger
    {
        public void WriteLog(string Message);
    }
}
