﻿using System;
using System.Diagnostics;
using System.Configuration;

namespace DIP_Demo
{
    public class Program
    {
        static void Main(string[] args)
        {
            MyLogger logger = new MyLogger();

            logger.AddLog(string.Format(" **** Message added on {0} **** ",
                DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") ));

            Console.WriteLine("Log Added");
            Console.Read();
        }
    }

    public class MyLogger 
    {
        public void AddLog(string Message)
        {
            // Tightly Coupled Implementation
            // High Level Class "MyLogger" is Depends with
            // Low Level Class "SystemEventLogger" / "DBLogger" / "FileLogger" 
           // DBLogger dbLogger = new DBLogger();

            // Loosely Coupled Implementation
            // High Level Class "MyLogger" is **Not** Depends with
            // Low Level Class "SystemEventLogger" / "DBLogger" / "FileLogger" 
            ILogger obj = LoggerFactory.GetLogger();
            obj.WriteLog(Message);
        }     
    }

    public class DBLogger : ILogger
    {
        public void WriteLog(string Message)
        {
            // DB Logic need to be here
            Console.WriteLine(Message);
            Console.WriteLine(" **** Log Added in Database  **** ");
        }
    }

    public class SystemEventLogger : ILogger 
    {
        public void WriteLog(string Message)
        {
            EventLog obj = new EventLog();

            obj.Source = "Application";           
            obj.WriteEntry(Message, EventLogEntryType.Error);

        }
    }

    public class FileLogger : ILogger
    {
        public void WriteLog(string Message)
        {
            // File Logic need to be here
            Console.WriteLine(Message);
            Console.WriteLine(" **** Log Added in Local File System  **** ");
        }
    }
}
