﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace DIP_Demo
{
    public class LoggerFactory
    {
        public static ILogger GetLogger()
        {
            ILogger LogSource;

            switch (ConfigurationManager.AppSettings["Logger"])
            {
                case "E":
                    LogSource = new SystemEventLogger();
                    break;
                case "D":
                    LogSource = new DBLogger();
                    break;
                case "F":
                    LogSource = new FileLogger();
                    break;
                default:
                    LogSource = new DBLogger();
                    break;
            }

            return LogSource;
        }

    }
}
