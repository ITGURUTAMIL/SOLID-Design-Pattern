﻿using System;

using DesignPrinciple.SRP;

namespace DesignPrinciple
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WithoutSRP Obj = new WithoutSRP();
            WithSRP Obj1 = new WithSRP();
            Obj.DoTransaction();
            Obj1.DoTransaction();

            Console.ReadLine();
        }
    }
}
