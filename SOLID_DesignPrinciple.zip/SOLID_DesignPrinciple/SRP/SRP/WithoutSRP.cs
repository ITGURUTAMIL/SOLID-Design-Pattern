﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPrinciple.SRP
{
    public class WithoutSRP
    {
        public void DoTransaction()
        {
            Validate();
            Purchase();
            Notify();
        }
        private void Validate()
        {
            Console.WriteLine("Do Purchase validation");
        }

        private void Purchase()
        {
            Console.WriteLine("Do Purchase");
        }

        private void Notify()
        {
            Console.WriteLine("Send Notification");
        }
    }
}
