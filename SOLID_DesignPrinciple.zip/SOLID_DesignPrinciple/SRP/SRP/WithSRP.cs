﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPrinciple.SRP
{
    public class WithSRP
    {
        public void DoTransaction()
        {
            Validation ValidationObj = new Validation();
            Purchase PurchaseObj = new Purchase();  
            Notification NotificationObj = new Notification();  
            ValidationObj.Validate();
            PurchaseObj.DoPurchase();
            NotificationObj.Notify();
        }
    }
}
