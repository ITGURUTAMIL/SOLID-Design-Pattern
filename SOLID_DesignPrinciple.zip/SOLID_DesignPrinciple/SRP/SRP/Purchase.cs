﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPrinciple.SRP
{
    internal class Purchase
    {
        public void DoPurchase()
        {
            Console.WriteLine("Do Purchase");
        }
    }
}
