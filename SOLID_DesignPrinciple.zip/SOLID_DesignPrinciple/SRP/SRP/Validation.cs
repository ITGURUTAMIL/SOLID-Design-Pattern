﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPrinciple.SRP
{
    internal class Validation
    {
        public void Validate()
        {
            Console.WriteLine("Do Purchase validation");
        }
    }
}
