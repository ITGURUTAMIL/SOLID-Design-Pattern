﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPrinciple.SRP
{
    internal class Notification
    {
        public void Notify()
        {
            Console.WriteLine("Send Notification");
        }
    }
}
