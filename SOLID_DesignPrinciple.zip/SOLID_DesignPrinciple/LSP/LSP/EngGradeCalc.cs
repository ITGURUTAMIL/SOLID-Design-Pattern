﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LSP
{
    public class EngGradeCalc : GradeCalc
    {
        public override string GetGrade(Student student)
        {
            string grade = string.Empty;
            
            if (string.IsNullOrEmpty(student.Name))
            {
                throw new Exception("Invalid student Name");
            }

            if (string.IsNullOrEmpty(student.StudentId))
            {
                throw new Exception("Invalid student Id");
            }
            // Extra Validation not allowed - LSP 
            //if (string.IsNullOrEmpty(student.EMail))
            //{
            //    throw new Exception("Invalid Email Id");
            //}

            int total = student.Maths + student.Science;  

            double avg = total / 2;
 
            if (avg > 90)
                grade = "A";
            else if (avg > 65)
                grade = "B";
            else if (avg > 40)
                grade = "C";
            else
                grade = "NA";

            return grade;
        }
    }
}
