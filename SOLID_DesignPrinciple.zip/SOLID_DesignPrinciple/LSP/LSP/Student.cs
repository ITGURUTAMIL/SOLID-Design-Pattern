﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LSP
{
    public class Student
    {
        public string Name { get; set; }    
        public string StudentId { get; set; }
        public string Grade { get; set; }
        public string Section { get; set; }
        public int Tamil { get; set; }  
        public int English { get; set; }    
        public int Maths { get; set; }  
        public int Science { get; set; }
        public int SocialScience { get; set; }
        public string EMail { get; set; }   
    }

}
