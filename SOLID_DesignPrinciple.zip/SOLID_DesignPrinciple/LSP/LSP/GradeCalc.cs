﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LSP
{
    public class GradeCalc
    {
        public virtual string GetGrade(Student student)
        {
            string grade = string.Empty;

            if (string.IsNullOrEmpty(student.Name))
            {
                throw new Exception("Invalid student Name");
            }

            if (string.IsNullOrEmpty(student.StudentId))
            {
                throw new Exception("Invalid student Id");
            }

            int total = student.Tamil + student.English +
                student.Maths + student.Science + student.SocialScience;

            double avg = total / 5;

            if (avg > 95)
                grade = "A+";
            else if (avg > 90)
                grade = "A";
            else if (avg > 80)
                grade = "B+";
            else if (avg > 60)
                grade = "B";
            else if (avg > 50)
                grade = "C+";
            else if (avg > 40)
                grade = "C";
            else
                grade = "NA";

            return grade;
        }

        public void SendGradeByEmail(Student student)
        {
            // Get Grade Details
            // Send GFrade details by E-Mail
        }
    }
}
