﻿using System;

namespace LSP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student()
            {
                Name    =   "Raja",
                StudentId   =   "2022090225",
                EMail   =   "Raja.R@gmail.com",
                Tamil   = 43,
                English = 45,
                Maths   = 38,
                Science = 36,
                SocialScience   = 36
            };

            try
            {
                GradeCalc calc;  /// Base Class reference

                calc = new GradeCalc();
                student.Grade = calc.GetGrade(student);
                Console.WriteLine("Basic Grade : " + student.Grade);
                ShowClass(student);

                calc = new EngGradeCalc();
                student.Grade = calc.GetGrade(student);
                Console.WriteLine("Eng Grade : " + student.Grade);
                ShowClass(student);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
            Console.ReadKey();
        }

        public static void ShowClass (Student student)
        {
               switch (student.Grade)
            {
                case "A+":
                case "A":
                case "B+":
                    Console.WriteLine("Completed in First Class");
                    break;
                case "B":
                case "C+":
                case "C":
                    Console.WriteLine("Completed in Second Class");
                    break;
                case "NA":
                    Console.WriteLine("Not Qualified");
                    break;
                default:
                    Console.WriteLine("Unknow Error in Class identification");
                    break;
            }
}
    }
}
