﻿using OCP.WithOCP;
using OCP.WithoutOCP;
using System;

namespace OCP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer
            {
                Name = "Vijay",
                Age = 24,
                IsEmployee = true,
                ExistingCustomer = true
            };
            
            DiscountCalc calc = new DiscountCalc();

            customer.InsuranceType = "Home";
            double discount = calc.GetDiscount(customer);
            Console.WriteLine(@"Customer got discount {0} %", discount);

            customer.InsuranceType = "Health";
            discount = calc.GetDiscount(customer);
            Console.WriteLine(@"Customer got discount {0} %", discount);

            customer.InsuranceType = "Car";
            discount = calc.GetDiscount(customer);
            Console.WriteLine(@"Customer got discount {0} %", discount);

            CustomerOCP customer1 = new CustomerOCP
            {
                Name = "Vijay",
                Age = 24,
                IsEmployee = true,
                ExistingCustomer = true
            };

            Console.WriteLine(" *** With OCP Approach *****");

            DiscountCalcOCP calc1 = new DiscountCalcOCP();

            customer1.InsuranceType = new Home();
             discount = calc1.GetDiscount(customer1);
            Console.WriteLine(@"Customer got discount {0} %", discount);


            customer1.InsuranceType = new Health();
            discount = calc1.GetDiscount(customer1);
            Console.WriteLine(@"Customer got discount {0} %", discount);


            customer1.InsuranceType = new Car();
            discount = calc1.GetDiscount(customer1);
            Console.WriteLine(@"Customer got discount {0} %", discount);


            Console.ReadLine();
        }
    }
}
