﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithOCP 
{
    public class Home : IInsType
    {
        public double DiscountCalc(CustomerOCP customer)
        {
           Double discount = 0.0;
            
                if (customer.IsEmployee)
                    discount += 1.5;
                if (customer.Age < 25)
                    discount += .75;
                if (customer.ExistingCustomer)
                    discount -= .5;

                return discount;
            
        }
    }
}
