﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithOCP
{
    public class Health : IInsType
    {
        public double DiscountCalc(CustomerOCP customer)
        {
            Double discount = 0.0;

            if (customer.IsEmployee)
                discount += 1;
            if (customer.Age < 25)
                discount += 1;
            if (customer.Age > 25 && customer.Age < 40)
                discount += .5;
            if (customer.Age > 40 && customer.Age < 55)
                discount += .25;

            return discount;

        }

    }
}