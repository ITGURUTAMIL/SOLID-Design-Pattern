﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithOCP 
{
    public class Car : IInsType
    {
        public double DiscountCalc(CustomerOCP customer)
        {
            Double discount = 0.0;

            if (customer.IsEmployee)
                discount += .5;
            if (customer.ExistingCustomer)
                discount = 0;

            return discount;

        }

    }
}
