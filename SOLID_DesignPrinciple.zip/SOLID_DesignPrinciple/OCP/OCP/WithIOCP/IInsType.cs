﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithOCP
{
    public interface IInsType
    {
        public double DiscountCalc(CustomerOCP customer);
    }
}
