﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 Modified Date : 06/12/2022
 Desc : Discount logic added for Home and Health
 */
namespace OCP.WithOCP
{
    public class DiscountCalcOCP
    {
        double discount = 0.0;

        public double GetDiscount(CustomerOCP customer)
        {
            discount = 0.0;

            discount = customer.InsuranceType.DiscountCalc(customer);

            return discount;
        }
    }
}
