﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithOCP
{
    public  class CustomerOCP
    {
        public  string Name { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }

        public bool ExistingCustomer { get; set; }
        public bool IsEmployee { get; set; }

        public IInsType InsuranceType     { get; set; }
    }
}
