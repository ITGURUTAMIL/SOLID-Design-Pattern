﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 Modified Date : 06/12/2022
 Desc : Discount logic added for Home and Health

 Modified Date : 07/19/2022
 Desc : Discount logic added for Car

 Modified Date : 08/23/2022
 Desc : Discount logic added for Bike

 */
namespace OCP.WithoutOCP
{
    public class DiscountCalc
    {
        double discount = 0.0;

        public double GetDiscount(Customer customer)
        {
            discount = 0.0;

            if (customer.InsuranceType.Equals("Home"))
            {
                if (customer.IsEmployee)
                    discount += 1.5;
                if (customer.Age < 25)
                    discount += .75;
                if (customer.ExistingCustomer)
                    discount -= .5;
            }
            if (customer.InsuranceType.Equals("Health"))
            {
                if (customer.IsEmployee)
                    discount += 1;
                if (customer.Age < 25)
                    discount += 1;
                if (customer.Age > 25 && customer.Age < 40)
                    discount += .5;
                if (customer.Age > 40 && customer.Age < 55)
                    discount += .25;
            }

            if (customer.InsuranceType.Equals("Car"))
            {
                if (customer.IsEmployee)
                    discount += .5;
                if (customer.ExistingCustomer)
                    discount =0;
            }

            return discount;
        }
    }
}
