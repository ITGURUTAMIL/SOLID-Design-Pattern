﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OCP.WithoutOCP
{
    public  class Customer
    {
        public  string Name { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }

        public bool ExistingCustomer { get; set; }
        public bool IsEmployee { get; set; }

        public string InsuranceType     { get; set; }
    }
}
