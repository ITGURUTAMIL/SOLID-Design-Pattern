﻿using System;

using WISP = ISP_Demo.Interfaces.WithISP;
using WOISP = ISP_Demo.Interfaces.WithoutISP;

namespace ISP_Demo
{
    public class Program
    {
        static void Main(string[] args)
        {
        
           WISP.ScienceCalculator scienceCalc = new WISP.ScienceCalculator();

           WOISP.ScienceCalculator scienceCalc1 = new WOISP.ScienceCalculator();

            Console.WriteLine (scienceCalc.Tan(45));
            Console.WriteLine(scienceCalc1.Cos(45));

            Console.ReadKey();
        }
    }
}
