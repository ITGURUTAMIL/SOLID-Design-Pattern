﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ISP_Demo.Interfaces.WithISP
{
    public class BasicCalculator : IBasicCalculator 
    {
        public double Addition(double p1, double p2)
        {
            return p1 + p2;
        }

        public double Division(double p1, double p2)
        {
            return p1 / p2;
        }
        public double Multiply(double p1, double p2)
        {
            return p1 * p2;
        }

        public double Subtraction(double p1, double p2)
        {
            return p1 - p2;
        }
    }
}
