﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ISP_Demo.Interfaces.WithISP
{
    public interface IScienceCalculator : IBasicCalculator
    {
        public double Sin(double p1);
        public double Cos(double p1);
        public double Tan(double p1);
        public double Log(double p1, double p2);
    }
}
