﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ISP_Demo.Interfaces.WithoutISP
{
    public interface ICalculator
    {
        public double Addition(double p1, double p2);
        public double Subtraction(double p1, double p2);
        public double Multiply(double p1, double p2);
        public double Division(double p1, double p2);
        public double Sin(double p1);
        public double Cos(double p1);
        public double Tan(double p1);
        public double Log(double p1, double p2);

    }
}
