﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ISP_Demo.Interfaces.WithoutISP
{
    public class BasicCalculator : ICalculator
    {
        public double Cos(double p1)
        {
            throw new NotImplementedException();
        }
        public double Log(double p1, double p2)
        {
            throw new NotImplementedException();
        }
        public double Sin(double p1)
        {
            throw new NotImplementedException();
        }
        public double Tan(double p1)
        {
            throw new NotImplementedException();
        }
        public double Addition(double p1, double p2)
        {
            return p1 + p2; 
        }
        public double Division(double p1, double p2)
        {
            return p1 / p2;
        }
        public double Multiply(double p1, double p2)
        {
            return p1 * p2;
        }

        public double Subtraction(double p1, double p2)
        {
            return p1 - p2; 
        }

    }
}
