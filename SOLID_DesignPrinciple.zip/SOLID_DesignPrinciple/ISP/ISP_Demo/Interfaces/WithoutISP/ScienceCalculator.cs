﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ISP_Demo.Interfaces.WithoutISP
{
    public class ScienceCalculator : ICalculator
    {
        public double Addition(double p1, double p2)
        {
            return p1 + p2;
        }

        public double Cos(double p1)
        {
            return Math.Cos(p1);
        }

        public double Division(double p1, double p2)
        {
            return p1 / p2;
        }

        public double Log(double p1, double p2)
        {
            return Math.Log(p1, p2);
        }

        public double Multiply(double p1, double p2)
        {
            return p1 * p2;
        }

        public double Sin(double p1)
        {
            return Math.Sin(p1);
        }

        public double Subtraction(double p1, double p2)
        {
            return p1 - p2;
        }

        public double Tan(double p1)
        {
            return Math.Tan(p1);
        }
    }
}
